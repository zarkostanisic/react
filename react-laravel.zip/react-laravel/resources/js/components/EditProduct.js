import React, { Component } from 'react';

class EditProduct extends Component{
  constructor(props){
    super(props);
    
    this.state = {
      updateProduct: {
        title: props.product.title || '',
        description: props.product.description || '',
        price: props.product.price || 0,
        availability: 0
      }
    };
    
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleInput = this.handleInput.bind(this);
  }
  
  handleInput(key, e){
    var state = Object.assign({}, this.state.updateProduct);
    state[key] = e.target.value;
    
    this.setState({updateProduct: state});
  }
  
  handleSubmit(e){
    e.preventDefault();
    
    this.props.onUpdate(this.state.updateProduct);
  }
  
  render(){
    const product = this.props.product;
    
    if(!product){
      return(
        <div>
          Please Select Product.
        </div>
      );
    }
    
    return(
      <div>
        <h2>Edit product</h2>
        <div>
          <form onSubmit={this.handleSubmit}>
            <label>
              Title:
              <input type="text" onChange={(e) => this.handleInput('title', e)} value={ this.state.updateProduct.title }/>
            </label>
            
            <label>
              Description:
              <input type="text" onChange={(e) => this.handleInput('description', e)} value={ this.state.updateProduct.description }/>
            </label>
            
            <label>
              Price:
              <input type="text" onChange={(e) =>this.handleInput('price', e) } value={ this.state.updateProduct.price }/>  
            </label>
            
            <input type="submit" value="EDIT"/>
          </form>
        </div>
      </div>
    );
  }
}

export default EditProduct;
 
